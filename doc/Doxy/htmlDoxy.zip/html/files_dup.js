var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "libs", "dir_6719ab1f1f7655efc2fa43f7eb574fd1.html", "dir_6719ab1f1f7655efc2fa43f7eb574fd1" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ]
];