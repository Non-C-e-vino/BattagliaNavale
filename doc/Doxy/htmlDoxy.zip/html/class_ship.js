var class_ship =
[
    [ "full_heal", "class_ship.html#a0cd7290438b7730db82022895556a4af", null ],
    [ "get_action", "class_ship.html#acc95f5650963a4835dfcd0dbb94cf121", null ],
    [ "get_hull", "class_ship.html#a8267c84adabae873d864f538ebb6959c", null ],
    [ "get_size", "class_ship.html#a6df77f37ad7332618c8a346309e221a7", null ],
    [ "heal", "class_ship.html#ab7b9894c4e3213d60e120418dc31c0f2", null ],
    [ "is_core", "class_ship.html#a15356b38aa60e2753ce084c306a71c50", null ],
    [ "is_sunk", "class_ship.html#a4c35fcd6a1513160a65061f5a4b1c423", null ],
    [ "set_damage", "class_ship.html#ac3f3030059714fa6ce6c61e4a562b751", null ],
    [ "hp", "class_ship.html#aa2d86cea2f0912918e0ab9d23cecb0b1", null ]
];