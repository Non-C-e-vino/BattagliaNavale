var class_nave_supporto =
[
    [ "NaveSupporto", "class_nave_supporto.html#a2ec691fd14b1b94e4deb2e48ce98b594", null ],
    [ "NaveSupporto", "class_nave_supporto.html#ab17c8ea98d428168b35867af3e0c4ef7", null ],
    [ "full_heal", "class_nave_supporto.html#a1f848022e5ce6b04ad26c2ed3d8196b2", null ],
    [ "get_action", "class_nave_supporto.html#a77d8ffb199dcbee4c7a458daa22020a5", null ],
    [ "get_hull", "class_nave_supporto.html#a6bdbedd7d7cb77afbe217790cd9432fd", null ],
    [ "get_size", "class_nave_supporto.html#a835388db2f4020be28747937cf8447fd", null ],
    [ "heal", "class_nave_supporto.html#af0d20730e49a63da6ab81cc4199d5c87", null ],
    [ "is_core", "class_nave_supporto.html#afd9e83dcbfad649ada06b7a2f8513e20", null ],
    [ "operator=", "class_nave_supporto.html#a834afdf684ae61186005da7500320f37", null ],
    [ "hull", "class_nave_supporto.html#a32e9122913b49bfd019414bd1e5a06e4", null ]
];