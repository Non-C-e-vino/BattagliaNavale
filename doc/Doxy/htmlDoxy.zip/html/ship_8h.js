var ship_8h =
[
    [ "Ship", "class_ship.html", "class_ship" ],
    [ "Hull", "struct_hull.html", "struct_hull" ],
    [ "ShipAction", "ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4b", [
      [ "Fire", "ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4babd2b7e5f85a6ea65065c4ebc6d7c95bb", null ],
      [ "MoveAndRepair", "ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4ba605c02cbe2df51c9aea2488913b39164", null ],
      [ "MoveAndSearch", "ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4baf89cee2cfa6907845c942c0fddd47a82", null ]
    ] ],
    [ "ShipType", "ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79", [
      [ "Cor", "ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79aa69b6dcbd29cc775147bfbb79650b7b9", null ],
      [ "NDS", "ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79a762ba5f7878627c28916f73f55646717", null ],
      [ "Sot", "ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79a6d8bb1937e70a7f57ac519f8321021c5", null ]
    ] ]
];