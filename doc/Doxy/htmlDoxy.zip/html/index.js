var index =
[
    [ "imp_sec", "index.html#imp_sec", [
      [ "Ottimizzazione", "index.html#ott_sec", null ],
      [ "Problemi strutturali", "index.html#des_sec", null ],
      [ "Problemi di leggibilita'", "index.html#leg_sec", null ]
    ] ]
];