var logger_8h =
[
    [ "InLogger", "class_in_logger.html", "class_in_logger" ],
    [ "OutLogger", "class_out_logger.html", "class_out_logger" ],
    [ "reset_log_file", "logger_8h.html#a0864366834b34bf1db4de9fb9888d4e9", null ]
];