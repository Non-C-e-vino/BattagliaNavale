var game_handler_8h =
[
    [ "GameHandler", "class_game_handler.html", "class_game_handler" ],
    [ "GameHandler::Bot", "class_game_handler_1_1_bot.html", "class_game_handler_1_1_bot" ],
    [ "GameHandler::CleverBot", "class_game_handler_1_1_clever_bot.html", "class_game_handler_1_1_clever_bot" ],
    [ "GAMEHAMDLER_H", "game_handler_8h.html#a8c97520f8efc8a79b0f4230dd60aa2ca", null ]
];