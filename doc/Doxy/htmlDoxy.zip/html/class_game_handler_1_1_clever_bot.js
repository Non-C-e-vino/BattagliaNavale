var class_game_handler_1_1_clever_bot =
[
    [ "CleverBot", "class_game_handler_1_1_clever_bot.html#a174a5e5188b05dde4589a498af083b35", null ],
    [ "gen_clever_coord", "class_game_handler_1_1_clever_bot.html#a57774cbdf09f46d855eff67ac6cce8ef", null ],
    [ "get_ship_act", "class_game_handler_1_1_clever_bot.html#a932b1a9d24f659cf758c6da35a16ff85", null ],
    [ "hasScanned", "class_game_handler_1_1_clever_bot.html#a014fb4cd1361e4df0d2f07b025bcdd1a", null ],
    [ "shootingTime", "class_game_handler_1_1_clever_bot.html#a33366009d071fda8bb992145f9bd3d70", null ],
    [ "targets", "class_game_handler_1_1_clever_bot.html#a7f0c546283d2bc91c1b793ec47983125", null ]
];