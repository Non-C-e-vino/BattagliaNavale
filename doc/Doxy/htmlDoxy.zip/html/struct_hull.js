var struct_hull =
[
    [ "Hull", "struct_hull.html#a9e31b2ef66c754c45b6205071e0c3175", null ],
    [ "Hull", "struct_hull.html#ab0b0039e4864d8dbc9e462b32b1e2200", null ],
    [ "get_c", "struct_hull.html#ab24b0e6b44f2b61fd4e3072177ad5312", null ],
    [ "getOwner", "struct_hull.html#a52053bbf7c7f609bb16b1176c722a4d8", null ],
    [ "heal", "struct_hull.html#ada7347e150d50ff0c4a2eec13db9d765", null ],
    [ "is_hit", "struct_hull.html#a633e807353db33bfe8e75292f9e3840f", null ],
    [ "set_c", "struct_hull.html#a449452aa19a293903431652b83031377", null ],
    [ "set_hit", "struct_hull.html#aec8002d7d00ff77fa0a237c1a9b57328", null ],
    [ "armor", "struct_hull.html#a6b2b669f6adb37efdd2e9a3d93c97b7f", null ],
    [ "c", "struct_hull.html#a22fe4ab45c9a0ed269fd6a207b3145c6", null ],
    [ "owner", "struct_hull.html#a7b8b45941ed7f94e0ed8d26e180d702c", null ]
];