var class_player =
[
    [ "get_ship_act", "class_player.html#adb0798f1b803735d70928bc3efa5549e", null ],
    [ "get_ship_pos", "class_player.html#aaa34d96f41c699857fcc73f13c8ca1a3", null ]
];