var admiral_8h =
[
    [ "Admiral", "struct_admiral.html", "struct_admiral" ],
    [ "Admirals", "admiral_8h.html#acf6983f9e206347179dc818eedc66e6f", [
      [ "RedAdm", "admiral_8h.html#acf6983f9e206347179dc818eedc66e6fa30c8de6245569c2e3b63469426d11f04", null ],
      [ "BlueAdm", "admiral_8h.html#acf6983f9e206347179dc818eedc66e6fa116c36c5c0a5486e567f25b1d8e7792f", null ]
    ] ]
];