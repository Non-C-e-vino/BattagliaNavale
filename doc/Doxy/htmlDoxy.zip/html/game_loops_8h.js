var game_loops_8h =
[
    [ "game_loop", "game_loops_8h.html#a78e9ee22511ac11a7be24616b2bec10d", null ],
    [ "init_loop", "game_loops_8h.html#ae9ad05f6bbcc0e683082fbe789b2b4e6", null ],
    [ "main_loop", "game_loops_8h.html#a4400aa13eed5e5436eec13f199db624c", null ]
];