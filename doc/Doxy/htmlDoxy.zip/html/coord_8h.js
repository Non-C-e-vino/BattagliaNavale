var coord_8h =
[
    [ "XY", "struct_x_y.html", "struct_x_y" ],
    [ "Rotation", "coord_8h.html#a4940d1dc528122726d2c8c475657e1a9", [
      [ "vert", "coord_8h.html#a4940d1dc528122726d2c8c475657e1a9a834932d06c05afc78322a5bbf48d72b9", null ],
      [ "oriz", "coord_8h.html#a4940d1dc528122726d2c8c475657e1a9a88fa67680560abd4db53f4cdba6e8472", null ]
    ] ],
    [ "char_to_coord", "coord_8h.html#a90bc364532fa9fca45efa64e725bc55f", null ],
    [ "check_c_oob", "coord_8h.html#a607bb56061c53ff4d314d791321e1411", null ],
    [ "coord_to_char", "coord_8h.html#ae924ceb5b92eabf36e01010d98cd8e36", null ],
    [ "operator+", "coord_8h.html#a7a87c33701ed3d037941cb293672ab99", null ],
    [ "operator-", "coord_8h.html#a7b8441c6f84ad42ba295b4f4964c2c64", null ],
    [ "print_char_coord", "coord_8h.html#af410bcb8e1642d4682771fb062a8448b", null ]
];