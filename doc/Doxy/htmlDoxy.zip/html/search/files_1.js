var searchData=
[
  ['battaglia_5fnavale_2ecpp_0',['battaglia_navale.cpp',['../battaglia__navale_8cpp.html',1,'']]],
  ['bot_2ecpp_1',['bot.cpp',['../bot_8cpp.html',1,'']]]
];
