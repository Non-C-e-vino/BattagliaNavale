var indexSectionsWithContent =
{
  0: "abcdfghilmnoprstvx~",
  1: "abcghinoprsx",
  2: "gl",
  3: "abcghlnprs",
  4: "abcdfghilmnoprsx~",
  5: "acdghilmorstx",
  6: "ars",
  7: "bcfmnorsv",
  8: "dg",
  9: "bn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

