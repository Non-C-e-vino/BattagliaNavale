var searchData=
[
  ['oriz_0',['oriz',['../coord_8h.html#a4940d1dc528122726d2c8c475657e1a9a88fa67680560abd4db53f4cdba6e8472',1,'coord.h']]]
];
