var searchData=
[
  ['read_5fcoin_5flog_0',['read_coin_log',['../class_in_logger.html#a91bd2ae739a69b1d448debca678115cd',1,'InLogger']]],
  ['read_5flog_1',['read_log',['../class_in_logger.html#a25358131977740e9521695a4268e4b1f',1,'InLogger']]],
  ['readme_2emd_2',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['redadm_3',['RedAdm',['../admiral_8h.html#acf6983f9e206347179dc818eedc66e6fa30c8de6245569c2e3b63469426d11f04',1,'admiral.h']]],
  ['remove_5fall_5fsunk_4',['remove_all_sunk',['../class_game_handler.html#abbfd45bfe7e1361545dda54176062dcf',1,'GameHandler']]],
  ['replay_2ecpp_5',['replay.cpp',['../replay_8cpp.html',1,'']]],
  ['replay_5finit_5floop_6',['replay_init_loop',['../namespacegame_loops.html#a108fdbe27ab7534f2800d05c042522ee',1,'gameLoops']]],
  ['replay_5floop_7',['replay_loop',['../namespacegame_loops.html#a8619d08b10260923590625cf3498053e',1,'gameLoops']]],
  ['replay_5fmain_5floop_8',['replay_main_loop',['../namespacegame_loops.html#a08b227e522a481075fe03b218027fea8',1,'gameLoops']]],
  ['replayloops_2ecpp_9',['replayLoops.cpp',['../replay_loops_8cpp.html',1,'']]],
  ['replayloops_2eh_10',['replayLoops.h',['../replay_loops_8h.html',1,'']]],
  ['reset_5flog_5ffile_11',['reset_log_file',['../namespace_log.html#a0864366834b34bf1db4de9fb9888d4e9',1,'Log']]],
  ['rico_12',['RICO',['../game_vars_8h.html#afb9f06c4987595ed06da3d697a434f7a',1,'gameVars.h']]],
  ['ricognitore_13',['Ricognitore',['../class_ricognitore.html',1,'Ricognitore'],['../class_ricognitore.html#adeaf8bb76f1b27b6f4b3b99c834d7b74',1,'Ricognitore::Ricognitore(const Ricognitore &amp;)=delete'],['../class_ricognitore.html#adb13a10562336705734a9bfd2c2f231a',1,'Ricognitore::Ricognitore(XY *)']]],
  ['ricognitore_2ecpp_14',['ricognitore.cpp',['../ricognitore_8cpp.html',1,'']]],
  ['ricognitore_2eh_15',['ricognitore.h',['../ricognitore_8h.html',1,'']]],
  ['rotation_16',['Rotation',['../coord_8h.html#a4940d1dc528122726d2c8c475657e1a9',1,'coord.h']]]
];
