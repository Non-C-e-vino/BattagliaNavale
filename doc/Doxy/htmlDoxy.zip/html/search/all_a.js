var searchData=
[
  ['navesupporto_0',['NaveSupporto',['../class_nave_supporto.html',1,'NaveSupporto'],['../class_nave_supporto.html#a2ec691fd14b1b94e4deb2e48ce98b594',1,'NaveSupporto::NaveSupporto(const NaveSupporto &amp;)=delete'],['../class_nave_supporto.html#ab17c8ea98d428168b35867af3e0c4ef7',1,'NaveSupporto::NaveSupporto(XY *)']]],
  ['navesupporto_2ecpp_1',['naveSupporto.cpp',['../nave_supporto_8cpp.html',1,'']]],
  ['navesupporto_2eh_2',['naveSupporto.h',['../nave_supporto_8h.html',1,'']]],
  ['nds_3',['NDS',['../ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79a762ba5f7878627c28916f73f55646717',1,'ship.h']]],
  ['next_5fturn_4',['next_turn',['../class_game_handler.html#a77f94baca8f678e00506e1ff58184f91',1,'GameHandler']]],
  ['note_20di_20implementazione_5',['Note di implementazione',['../index.html',1,'']]]
];
