var searchData=
[
  ['heal_0',['heal',['../class_corazzata.html#acc7ec3fb2b77f49c6cbefa1bfd082b53',1,'Corazzata::heal()'],['../class_nave_supporto.html#af0d20730e49a63da6ab81cc4199d5c87',1,'NaveSupporto::heal()'],['../class_ricognitore.html#a9beca3b3df65d6cd056bb449b6cf693f',1,'Ricognitore::heal()'],['../class_ship.html#ab7b9894c4e3213d60e120418dc31c0f2',1,'Ship::heal()'],['../struct_hull.html#ada7347e150d50ff0c4a2eec13db9d765',1,'Hull::heal()']]],
  ['heal_5faoe_1',['heal_aoe',['../class_game_handler.html#ad31bd4005c13ab9e4eee9d42a8199155',1,'GameHandler']]],
  ['hull_2',['Hull',['../struct_hull.html#a9e31b2ef66c754c45b6205071e0c3175',1,'Hull::Hull()'],['../struct_hull.html#ab0b0039e4864d8dbc9e462b32b1e2200',1,'Hull::Hull(Ship *owner, XY &amp;c)']]]
];
