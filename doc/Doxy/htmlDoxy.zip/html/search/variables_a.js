var searchData=
[
  ['shipc_0',['shipC',['../struct_admiral.html#a3f5dd2fe9b5ad1e8c7931a549e258889',1,'Admiral']]],
  ['ships_1',['ships',['../struct_admiral.html#a978caee73d4c73d8b1a1d3af30b859b5',1,'Admiral']]],
  ['ships_5ftot_2',['SHIPS_TOT',['../game_vars_8h.html#a8261485db1311b63dc265980656c71c8',1,'gameVars.h']]],
  ['shootingtime_3',['shootingTime',['../class_game_handler_1_1_clever_bot.html#a33366009d071fda8bb992145f9bd3d70',1,'GameHandler::CleverBot']]],
  ['size_4',['size',['../class_corazzata.html#a78602d51143d81038019d39b799b1d98',1,'Corazzata::size()'],['../class_nave_supporto.html#a989c6a85fa895f9b0fdb91527037009f',1,'NaveSupporto::size()'],['../class_ricognitore.html#a05b3dee8525ffcaa3270ece15fd96207',1,'Ricognitore::size()']]],
  ['supp_5',['SUPP',['../game_vars_8h.html#a951f17e7027641c0ccae2fbe4c503888',1,'gameVars.h']]]
];
