var searchData=
[
  ['admiral_0',['admiral',['../class_game_handler.html#a74590cf0ee15c4e9ca97703739c88633',1,'GameHandler']]],
  ['armor_1',['armor',['../struct_hull.html#a6b2b669f6adb37efdd2e9a3d93c97b7f',1,'Hull']]],
  ['attgrid_2',['attGrid',['../struct_admiral.html#ae0f6202ce8371c0da892a3defb5ffcdd',1,'Admiral']]]
];
