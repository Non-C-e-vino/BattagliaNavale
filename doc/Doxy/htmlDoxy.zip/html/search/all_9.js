var searchData=
[
  ['main_0',['main',['../battaglia__navale_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;battaglia_navale.cpp'],['../replay_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;replay.cpp']]],
  ['main_5floop_1',['main_loop',['../namespacegame_loops.html#a4400aa13eed5e5436eec13f199db624c',1,'gameLoops']]],
  ['maxturns_2',['MAXTURNS',['../game_vars_8h.html#a525abd38aba373c22604a72e9b9226ec',1,'gameVars.h']]],
  ['move_5fship_3',['move_ship',['../class_game_handler.html#a095922e4c0183643482450b7878b17c3',1,'GameHandler']]],
  ['moveandrepair_4',['MoveAndRepair',['../ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4ba605c02cbe2df51c9aea2488913b39164',1,'ship.h']]],
  ['moveandsearch_5',['MoveAndSearch',['../ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4baf89cee2cfa6907845c942c0fddd47a82',1,'ship.h']]]
];
