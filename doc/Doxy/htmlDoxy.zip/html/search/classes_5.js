var searchData=
[
  ['inlogger_0',['InLogger',['../class_in_logger.html',1,'']]]
];
