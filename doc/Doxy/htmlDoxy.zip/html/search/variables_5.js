var searchData=
[
  ['ifsptr_0',['ifsptr',['../class_in_logger.html#a50963facbcd50efba9d38ed911289ded',1,'InLogger']]]
];
