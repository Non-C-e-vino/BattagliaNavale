var searchData=
[
  ['scout_0',['scout',['../class_game_handler.html#ab58629eb42d65dc90efe8a15f39b36d0',1,'GameHandler']]],
  ['set_5fc_1',['set_c',['../struct_hull.html#a449452aa19a293903431652b83031377',1,'Hull']]],
  ['set_5fcoin_2',['set_coin',['../class_game_handler.html#a4c317e730c21dbee1fbe7a18d6d2982d',1,'GameHandler']]],
  ['set_5fcores_3',['set_cores',['../class_game_handler.html#a07c45aab666a5fd9b7c694567ab7cd2e',1,'GameHandler']]],
  ['set_5fdamage_4',['set_damage',['../class_ship.html#ac3f3030059714fa6ce6c61e4a562b751',1,'Ship']]],
  ['set_5fhit_5',['set_hit',['../struct_hull.html#aec8002d7d00ff77fa0a237c1a9b57328',1,'Hull']]],
  ['set_5fship_6',['set_ship',['../class_game_handler.html#ab2efd2fb088df3cd060ebb3cfecdb8c2',1,'GameHandler']]],
  ['set_5fship_5fon_5fmap_7',['set_ship_on_map',['../class_game_handler.html#abbe5b9724b8e69d3727b59b44cd4b0db',1,'GameHandler::set_ship_on_map(std::unique_ptr&lt; Ship &gt; &amp;ship, Admirals adm)'],['../class_game_handler.html#ab9fb7fd00da272779ca9378352f8ef2c',1,'GameHandler::set_ship_on_map(Ship *ship, Admirals adm)']]],
  ['ship_8',['Ship',['../class_ship.html',1,'']]],
  ['ship_2ecpp_9',['ship.cpp',['../ship_8cpp.html',1,'']]],
  ['ship_2eh_10',['ship.h',['../ship_8h.html',1,'']]],
  ['ship_5faction_11',['ship_action',['../class_game_handler.html#aef486f2cb42bbb40ddb841df105ed0f3',1,'GameHandler']]],
  ['shipaction_12',['ShipAction',['../ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4b',1,'ship.h']]],
  ['shipc_13',['shipC',['../struct_admiral.html#a3f5dd2fe9b5ad1e8c7931a549e258889',1,'Admiral']]],
  ['ships_14',['ships',['../struct_admiral.html#a978caee73d4c73d8b1a1d3af30b859b5',1,'Admiral']]],
  ['ships_5ftot_15',['SHIPS_TOT',['../game_vars_8h.html#a8261485db1311b63dc265980656c71c8',1,'gameVars.h']]],
  ['shiptype_16',['ShipType',['../ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79',1,'ship.h']]],
  ['shootingtime_17',['shootingTime',['../class_game_handler_1_1_clever_bot.html#a33366009d071fda8bb992145f9bd3d70',1,'GameHandler::CleverBot']]],
  ['size_18',['size',['../class_corazzata.html#a78602d51143d81038019d39b799b1d98',1,'Corazzata::size()'],['../class_nave_supporto.html#a989c6a85fa895f9b0fdb91527037009f',1,'NaveSupporto::size()'],['../class_ricognitore.html#a05b3dee8525ffcaa3270ece15fd96207',1,'Ricognitore::size()']]],
  ['sot_19',['Sot',['../ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79a6d8bb1937e70a7f57ac519f8321021c5',1,'ship.h']]],
  ['supp_20',['SUPP',['../game_vars_8h.html#a951f17e7027641c0ccae2fbe4c503888',1,'gameVars.h']]]
];
