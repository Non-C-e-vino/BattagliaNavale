var searchData=
[
  ['cleverbot_0',['CleverBot',['../class_game_handler_1_1_clever_bot.html',1,'GameHandler']]],
  ['corazzata_1',['Corazzata',['../class_corazzata.html',1,'']]]
];
