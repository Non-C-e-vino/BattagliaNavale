var searchData=
[
  ['logfile_0',['LOGFILE',['../game_vars_8h.html#a425b48cf5207db5947f5caf82ebecb5e',1,'gameVars.h']]]
];
