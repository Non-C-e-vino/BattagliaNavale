var searchData=
[
  ['fire_0',['Fire',['../ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4babd2b7e5f85a6ea65065c4ebc6d7c95bb',1,'ship.h']]],
  ['flip_5fcoin_1',['flip_coin',['../class_game_handler.html#a4f581586dc4305539621915213bc92fc',1,'GameHandler']]],
  ['full_5fheal_2',['full_heal',['../class_corazzata.html#a1919124a03f4e78abbaba4880455b1a1',1,'Corazzata::full_heal()'],['../class_nave_supporto.html#a1f848022e5ce6b04ad26c2ed3d8196b2',1,'NaveSupporto::full_heal()'],['../class_ricognitore.html#a6fc0429172aa6ef665fee2e3f012b0de',1,'Ricognitore::full_heal()'],['../class_ship.html#a0cd7290438b7730db82022895556a4af',1,'Ship::full_heal()']]]
];
