var searchData=
[
  ['maxturns_0',['MAXTURNS',['../game_vars_8h.html#a525abd38aba373c22604a72e9b9226ec',1,'gameVars.h']]]
];
