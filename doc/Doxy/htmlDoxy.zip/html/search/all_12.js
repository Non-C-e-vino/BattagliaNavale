var searchData=
[
  ['_7eadmiral_0',['~Admiral',['../struct_admiral.html#a474b238f577da895fa744e8d0ac30b29',1,'Admiral']]],
  ['_7einlogger_1',['~InLogger',['../class_in_logger.html#a9870ec00199170c0cbbcd26b15ee2131',1,'InLogger']]],
  ['_7eoutlogger_2',['~OutLogger',['../class_out_logger.html#a5b00db46ba937a43bd3ed13a13c20a06',1,'OutLogger']]]
];
