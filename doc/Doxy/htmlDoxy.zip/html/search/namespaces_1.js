var searchData=
[
  ['log_0',['Log',['../namespace_log.html',1,'']]]
];
