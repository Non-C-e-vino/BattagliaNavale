var searchData=
[
  ['log_5fcinput_0',['log_cinput',['../class_out_logger.html#a3c58bbcbd7da13b2ec6dbf04b876cef5',1,'OutLogger']]],
  ['log_5fcoin_1',['log_coin',['../class_out_logger.html#a03d3d7db28bd3945dcc2aa5fea7598a9',1,'OutLogger']]]
];
