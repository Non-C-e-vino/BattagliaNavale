var searchData=
[
  ['note_20di_20implementazione_0',['Note di implementazione',['../index.html',1,'']]]
];
