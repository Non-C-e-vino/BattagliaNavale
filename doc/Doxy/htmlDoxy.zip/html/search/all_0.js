var searchData=
[
  ['action_5ffire_0',['action_fire',['../class_game_handler.html#a3f9f0575352c233cd789bbc4652137c4',1,'GameHandler']]],
  ['action_5fmove_5fheal_1',['action_move_heal',['../class_game_handler.html#ae4fe825094c482e9f7ee4ecea45b200c',1,'GameHandler']]],
  ['action_5fmove_5fsearch_2',['action_move_search',['../class_game_handler.html#a55c02d1603786dd71cfb8c074b3a785b',1,'GameHandler']]],
  ['add_5fship_3',['add_ship',['../struct_admiral.html#a43eefae2732367f1c4a527146a9ee98a',1,'Admiral']]],
  ['admiral_4',['Admiral',['../struct_admiral.html',1,'']]],
  ['admiral_5',['admiral',['../class_game_handler.html#a74590cf0ee15c4e9ca97703739c88633',1,'GameHandler']]],
  ['admiral_6',['Admiral',['../struct_admiral.html#aaa0b85d6e9c8dd437faaaac6b87bbfbe',1,'Admiral::Admiral(void)'],['../struct_admiral.html#a39133d0e007e70a80826094329be9496',1,'Admiral::Admiral(const Admiral &amp;)=delete']]],
  ['admiral_2ecpp_7',['admiral.cpp',['../admiral_8cpp.html',1,'']]],
  ['admiral_2eh_8',['admiral.h',['../admiral_8h.html',1,'']]],
  ['admirals_9',['Admirals',['../admiral_8h.html#acf6983f9e206347179dc818eedc66e6f',1,'admiral.h']]],
  ['argserror_10',['argsError',['../battaglia__navale_8cpp.html#a2fa91eebb61e2b60d0c70bc5a39b2851',1,'battaglia_navale.cpp']]],
  ['armor_11',['armor',['../struct_hull.html#a6b2b669f6adb37efdd2e9a3d93c97b7f',1,'Hull']]],
  ['attgrid_12',['attGrid',['../struct_admiral.html#ae0f6202ce8371c0da892a3defb5ffcdd',1,'Admiral']]]
];
