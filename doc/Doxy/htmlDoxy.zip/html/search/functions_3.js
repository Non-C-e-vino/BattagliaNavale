var searchData=
[
  ['delete_5fship_0',['delete_ship',['../struct_admiral.html#a968accb001ddf591d83d2f6d8151b2e4',1,'Admiral']]],
  ['detach_5fship_5ffrom_5fmap_1',['detach_ship_from_map',['../class_game_handler.html#aa76c2c95a6b635ed6a833435c5ddc815',1,'GameHandler']]],
  ['display_5fgrids_2',['display_grids',['../class_game_handler.html#a64aa4cceff6d2daa02d934f09b4fe3cd',1,'GameHandler']]]
];
