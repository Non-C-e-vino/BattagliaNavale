var searchData=
[
  ['targets_0',['targets',['../class_game_handler_1_1_clever_bot.html#a7f0c546283d2bc91c1b793ec47983125',1,'GameHandler::CleverBot']]],
  ['turn_1',['turn',['../class_game_handler.html#afd68e94e8a8ae683d625c394e9dd676d',1,'GameHandler']]]
];
