var searchData=
[
  ['navesupporto_0',['NaveSupporto',['../class_nave_supporto.html#a2ec691fd14b1b94e4deb2e48ce98b594',1,'NaveSupporto::NaveSupporto(const NaveSupporto &amp;)=delete'],['../class_nave_supporto.html#ab17c8ea98d428168b35867af3e0c4ef7',1,'NaveSupporto::NaveSupporto(XY *)']]],
  ['next_5fturn_1',['next_turn',['../class_game_handler.html#a77f94baca8f678e00506e1ff58184f91',1,'GameHandler']]]
];
