var searchData=
[
  ['hasscanned_0',['hasScanned',['../class_game_handler_1_1_clever_bot.html#a014fb4cd1361e4df0d2f07b025bcdd1a',1,'GameHandler::CleverBot']]],
  ['hp_1',['hp',['../class_ship.html#aa2d86cea2f0912918e0ab9d23cecb0b1',1,'Ship']]],
  ['hull_2',['hull',['../class_corazzata.html#afcf7b7eacef843bb9e7b94883e36738f',1,'Corazzata::hull()'],['../class_nave_supporto.html#a32e9122913b49bfd019414bd1e5a06e4',1,'NaveSupporto::hull()'],['../class_ricognitore.html#a3e4858d72df47faa93b5f0a691e9122b',1,'Ricognitore::hull()']]]
];
