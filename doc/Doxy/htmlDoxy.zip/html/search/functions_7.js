var searchData=
[
  ['init_5floop_0',['init_loop',['../namespacegame_loops.html#ae9ad05f6bbcc0e683082fbe789b2b4e6',1,'gameLoops']]],
  ['inlogger_1',['InLogger',['../class_in_logger.html#ae057db5290317020c36cc55839d034ad',1,'InLogger::InLogger(std::string &amp;)'],['../class_in_logger.html#a3c26346185eb1dee7e7037a4c00ad82e',1,'InLogger::InLogger(const InLogger &amp;)=delete']]],
  ['is_5fcore_2',['is_core',['../class_corazzata.html#ae988d61a999febfb12ec3852568f18a8',1,'Corazzata::is_core()'],['../class_nave_supporto.html#afd9e83dcbfad649ada06b7a2f8513e20',1,'NaveSupporto::is_core()'],['../class_ricognitore.html#a06745a2040e18a45b435a981ae4e121b',1,'Ricognitore::is_core()'],['../class_ship.html#a15356b38aa60e2753ce084c306a71c50',1,'Ship::is_core()']]],
  ['is_5fhit_3',['is_hit',['../struct_hull.html#a633e807353db33bfe8e75292f9e3840f',1,'Hull']]],
  ['is_5fsunk_4',['is_sunk',['../class_ship.html#a4c35fcd6a1513160a65061f5a4b1c423',1,'Ship']]],
  ['is_5fwinner_5',['is_winner',['../class_game_handler.html#a4ffa5429e642fac7ab6eaccba8ca51e3',1,'GameHandler']]]
];
