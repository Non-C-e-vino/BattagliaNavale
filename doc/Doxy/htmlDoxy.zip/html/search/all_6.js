var searchData=
[
  ['hasscanned_0',['hasScanned',['../class_game_handler_1_1_clever_bot.html#a014fb4cd1361e4df0d2f07b025bcdd1a',1,'GameHandler::CleverBot']]],
  ['heal_1',['heal',['../class_corazzata.html#acc7ec3fb2b77f49c6cbefa1bfd082b53',1,'Corazzata::heal()'],['../class_nave_supporto.html#af0d20730e49a63da6ab81cc4199d5c87',1,'NaveSupporto::heal()'],['../class_ricognitore.html#a9beca3b3df65d6cd056bb449b6cf693f',1,'Ricognitore::heal()'],['../class_ship.html#ab7b9894c4e3213d60e120418dc31c0f2',1,'Ship::heal()'],['../struct_hull.html#ada7347e150d50ff0c4a2eec13db9d765',1,'Hull::heal()']]],
  ['heal_5faoe_2',['heal_aoe',['../class_game_handler.html#ad31bd4005c13ab9e4eee9d42a8199155',1,'GameHandler']]],
  ['hp_3',['hp',['../class_ship.html#aa2d86cea2f0912918e0ab9d23cecb0b1',1,'Ship']]],
  ['hull_4',['Hull',['../struct_hull.html',1,'']]],
  ['hull_5',['hull',['../class_corazzata.html#afcf7b7eacef843bb9e7b94883e36738f',1,'Corazzata::hull()'],['../class_nave_supporto.html#a32e9122913b49bfd019414bd1e5a06e4',1,'NaveSupporto::hull()'],['../class_ricognitore.html#a3e4858d72df47faa93b5f0a691e9122b',1,'Ricognitore::hull()']]],
  ['hull_6',['Hull',['../struct_hull.html#a9e31b2ef66c754c45b6205071e0c3175',1,'Hull::Hull()'],['../struct_hull.html#ab0b0039e4864d8dbc9e462b32b1e2200',1,'Hull::Hull(Ship *owner, XY &amp;c)']]],
  ['humanplayer_7',['HumanPlayer',['../class_human_player.html',1,'']]],
  ['humanplayer_2ecpp_8',['humanPlayer.cpp',['../human_player_8cpp.html',1,'']]],
  ['humanplayer_2eh_9',['humanPlayer.h',['../human_player_8h.html',1,'']]]
];
