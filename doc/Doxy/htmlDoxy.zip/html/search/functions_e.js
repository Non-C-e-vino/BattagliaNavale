var searchData=
[
  ['scout_0',['scout',['../class_game_handler.html#ab58629eb42d65dc90efe8a15f39b36d0',1,'GameHandler']]],
  ['set_5fc_1',['set_c',['../struct_hull.html#a449452aa19a293903431652b83031377',1,'Hull']]],
  ['set_5fcoin_2',['set_coin',['../class_game_handler.html#a4c317e730c21dbee1fbe7a18d6d2982d',1,'GameHandler']]],
  ['set_5fcores_3',['set_cores',['../class_game_handler.html#a07c45aab666a5fd9b7c694567ab7cd2e',1,'GameHandler']]],
  ['set_5fdamage_4',['set_damage',['../class_ship.html#ac3f3030059714fa6ce6c61e4a562b751',1,'Ship']]],
  ['set_5fhit_5',['set_hit',['../struct_hull.html#aec8002d7d00ff77fa0a237c1a9b57328',1,'Hull']]],
  ['set_5fship_6',['set_ship',['../class_game_handler.html#ab2efd2fb088df3cd060ebb3cfecdb8c2',1,'GameHandler']]],
  ['set_5fship_5fon_5fmap_7',['set_ship_on_map',['../class_game_handler.html#abbe5b9724b8e69d3727b59b44cd4b0db',1,'GameHandler::set_ship_on_map(std::unique_ptr&lt; Ship &gt; &amp;ship, Admirals adm)'],['../class_game_handler.html#ab9fb7fd00da272779ca9378352f8ef2c',1,'GameHandler::set_ship_on_map(Ship *ship, Admirals adm)']]],
  ['ship_5faction_8',['ship_action',['../class_game_handler.html#aef486f2cb42bbb40ddb841df105ed0f3',1,'GameHandler']]]
];
