var searchData=
[
  ['vert_0',['vert',['../coord_8h.html#a4940d1dc528122726d2c8c475657e1a9a834932d06c05afc78322a5bbf48d72b9',1,'coord.h']]]
];
