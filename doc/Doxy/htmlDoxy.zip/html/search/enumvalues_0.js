var searchData=
[
  ['blueadm_0',['BlueAdm',['../admiral_8h.html#acf6983f9e206347179dc818eedc66e6fa116c36c5c0a5486e567f25b1d8e7792f',1,'admiral.h']]]
];
