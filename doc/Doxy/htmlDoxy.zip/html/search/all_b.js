var searchData=
[
  ['ofsptr_0',['ofsptr',['../class_out_logger.html#a1748a3f5cd881ad36f9b8b4b8c8201f1',1,'OutLogger']]],
  ['operator_21_3d_1',['operator!=',['../struct_x_y.html#a0fb389117f3c9956f4445af6be4c28e7',1,'XY']]],
  ['operator_2b_2',['operator+',['../coord_8h.html#a7a87c33701ed3d037941cb293672ab99',1,'operator+(const XY &amp;, const XY &amp;):&#160;coord.cpp'],['../coord_8cpp.html#ab615c6e827977cacbd2c3d962373310c',1,'operator+(const XY &amp;c1, const XY &amp;c2):&#160;coord.cpp']]],
  ['operator_2b_3d_3',['operator+=',['../struct_x_y.html#ae0f6b98b6cd34679119bef63b105e966',1,'XY']]],
  ['operator_2d_4',['operator-',['../coord_8h.html#a7b8441c6f84ad42ba295b4f4964c2c64',1,'operator-(const XY &amp;, const XY &amp;):&#160;coord.cpp'],['../coord_8cpp.html#a294b87dececb944f216d0363404840d2',1,'operator-(const XY &amp;c1, const XY &amp;c2):&#160;coord.cpp']]],
  ['operator_3c_5',['operator&lt;',['../struct_x_y.html#ac97d465b3194950141137f4dbb7df45f',1,'XY']]],
  ['operator_3d_6',['operator=',['../struct_admiral.html#a4b194d7f8969614868aba7589df3ef10',1,'Admiral::operator=()'],['../class_corazzata.html#a3182bfbe3cbfc764df6ce355fdfd43db',1,'Corazzata::operator=()'],['../class_in_logger.html#a1740135f5f5171ce599f02e7a0beb55a',1,'InLogger::operator=()'],['../class_out_logger.html#ab9cdc832f164f2e9e8b922452e67bba0',1,'OutLogger::operator=()'],['../class_nave_supporto.html#a834afdf684ae61186005da7500320f37',1,'NaveSupporto::operator=()'],['../class_ricognitore.html#a17924b76565aa0c2c122109061be3395',1,'Ricognitore::operator=()']]],
  ['operator_3d_3d_7',['operator==',['../struct_x_y.html#afbd34bd8e1726e4e0c6df3b196a9e72b',1,'XY']]],
  ['oriz_8',['oriz',['../coord_8h.html#a4940d1dc528122726d2c8c475657e1a9a88fa67680560abd4db53f4cdba6e8472',1,'coord.h']]],
  ['outlogger_9',['OutLogger',['../class_out_logger.html',1,'OutLogger'],['../class_out_logger.html#ab4c80cba912377fb9deab8e3557a6fbc',1,'OutLogger::OutLogger(void)'],['../class_out_logger.html#a181f50c4472987e63ee6e7a6eea2cd72',1,'OutLogger::OutLogger(const OutLogger &amp;)=delete']]],
  ['owner_10',['owner',['../struct_hull.html#a7b8b45941ed7f94e0ed8d26e180d702c',1,'Hull']]]
];
