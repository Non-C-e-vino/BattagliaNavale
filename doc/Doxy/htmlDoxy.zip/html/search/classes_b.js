var searchData=
[
  ['xy_0',['XY',['../struct_x_y.html',1,'']]]
];
