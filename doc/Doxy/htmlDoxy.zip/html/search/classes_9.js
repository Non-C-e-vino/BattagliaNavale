var searchData=
[
  ['ricognitore_0',['Ricognitore',['../class_ricognitore.html',1,'']]]
];
