var searchData=
[
  ['shipaction_0',['ShipAction',['../ship_8h.html#a2a8c703429897f9bd60bbd012b9f3a4b',1,'ship.h']]],
  ['shiptype_1',['ShipType',['../ship_8h.html#a2820e9c1accfd8c5b22461fa8b1a8e79',1,'ship.h']]]
];
