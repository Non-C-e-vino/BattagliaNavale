var searchData=
[
  ['admiral_0',['Admiral',['../struct_admiral.html',1,'']]]
];
