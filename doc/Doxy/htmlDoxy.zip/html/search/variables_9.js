var searchData=
[
  ['rico_0',['RICO',['../game_vars_8h.html#afb9f06c4987595ed06da3d697a434f7a',1,'gameVars.h']]]
];
