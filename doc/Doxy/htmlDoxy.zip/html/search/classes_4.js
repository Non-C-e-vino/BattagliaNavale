var searchData=
[
  ['hull_0',['Hull',['../struct_hull.html',1,'']]],
  ['humanplayer_1',['HumanPlayer',['../class_human_player.html',1,'']]]
];
