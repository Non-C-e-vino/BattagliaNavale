var searchData=
[
  ['defgrid_0',['defGrid',['../struct_admiral.html#a7270c8d81b48b7dfa56d773b7ecd0df2',1,'Admiral']]]
];
