var searchData=
[
  ['defgrid_0',['defGrid',['../struct_admiral.html#a7270c8d81b48b7dfa56d773b7ecd0df2',1,'Admiral']]],
  ['delay_5fms_1',['DELAY_MS',['../replay_8cpp.html#a70fb43de88d474f4c6e87dff47edf851',1,'replay.cpp']]],
  ['delete_5fship_2',['delete_ship',['../struct_admiral.html#a968accb001ddf591d83d2f6d8151b2e4',1,'Admiral']]],
  ['detach_5fship_5ffrom_5fmap_3',['detach_ship_from_map',['../class_game_handler.html#aa76c2c95a6b635ed6a833435c5ddc815',1,'GameHandler']]],
  ['display_5fgrids_4',['display_grids',['../class_game_handler.html#a64aa4cceff6d2daa02d934f09b4fe3cd',1,'GameHandler']]]
];
