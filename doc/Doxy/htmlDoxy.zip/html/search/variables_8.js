var searchData=
[
  ['ofsptr_0',['ofsptr',['../class_out_logger.html#a1748a3f5cd881ad36f9b8b4b8c8201f1',1,'OutLogger']]],
  ['owner_1',['owner',['../struct_hull.html#a7b8b45941ed7f94e0ed8d26e180d702c',1,'Hull']]]
];
