var searchData=
[
  ['action_5ffire_0',['action_fire',['../class_game_handler.html#a3f9f0575352c233cd789bbc4652137c4',1,'GameHandler']]],
  ['action_5fmove_5fheal_1',['action_move_heal',['../class_game_handler.html#ae4fe825094c482e9f7ee4ecea45b200c',1,'GameHandler']]],
  ['action_5fmove_5fsearch_2',['action_move_search',['../class_game_handler.html#a55c02d1603786dd71cfb8c074b3a785b',1,'GameHandler']]],
  ['add_5fship_3',['add_ship',['../struct_admiral.html#a43eefae2732367f1c4a527146a9ee98a',1,'Admiral']]],
  ['admiral_4',['Admiral',['../struct_admiral.html#aaa0b85d6e9c8dd437faaaac6b87bbfbe',1,'Admiral::Admiral(void)'],['../struct_admiral.html#a39133d0e007e70a80826094329be9496',1,'Admiral::Admiral(const Admiral &amp;)=delete']]],
  ['argserror_5',['argsError',['../battaglia__navale_8cpp.html#a2fa91eebb61e2b60d0c70bc5a39b2851',1,'battaglia_navale.cpp']]]
];
