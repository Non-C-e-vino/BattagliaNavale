var searchData=
[
  ['battaglia_5fnavale_2ecpp_0',['battaglia_navale.cpp',['../battaglia__navale_8cpp.html',1,'']]],
  ['battaglianavale_1',['BattagliaNavale',['../md__c___users_gabri__one_drive__documenti__code_git__battaglia_navale__r_e_a_d_m_e.html',1,'']]],
  ['blueadm_2',['BlueAdm',['../admiral_8h.html#acf6983f9e206347179dc818eedc66e6fa116c36c5c0a5486e567f25b1d8e7792f',1,'admiral.h']]],
  ['bot_3',['Bot',['../class_game_handler_1_1_bot.html#ad917eb997dd7864d2386666080888a0a',1,'GameHandler::Bot::Bot()'],['../class_game_handler_1_1_bot.html',1,'GameHandler::Bot']]],
  ['bot_2ecpp_4',['bot.cpp',['../bot_8cpp.html',1,'']]]
];
