var searchData=
[
  ['redadm_0',['RedAdm',['../admiral_8h.html#acf6983f9e206347179dc818eedc66e6fa30c8de6245569c2e3b63469426d11f04',1,'admiral.h']]]
];
