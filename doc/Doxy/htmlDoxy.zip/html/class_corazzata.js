var class_corazzata =
[
    [ "Corazzata", "class_corazzata.html#a5fb955ad7726f2d1cb654ea677c2eac2", null ],
    [ "Corazzata", "class_corazzata.html#aa05ef353c2d90bc1be72f2553f887eaa", null ],
    [ "full_heal", "class_corazzata.html#a1919124a03f4e78abbaba4880455b1a1", null ],
    [ "get_action", "class_corazzata.html#a4f93f42ea6a489dc04e89988953b9b65", null ],
    [ "get_hull", "class_corazzata.html#ae60cdf9825db6c1a887eac739934208c", null ],
    [ "get_size", "class_corazzata.html#a32374eff99cdcd8ba2feb1e5dd6b8351", null ],
    [ "heal", "class_corazzata.html#acc7ec3fb2b77f49c6cbefa1bfd082b53", null ],
    [ "is_core", "class_corazzata.html#ae988d61a999febfb12ec3852568f18a8", null ],
    [ "operator=", "class_corazzata.html#a3182bfbe3cbfc764df6ce355fdfd43db", null ],
    [ "hull", "class_corazzata.html#afcf7b7eacef843bb9e7b94883e36738f", null ]
];