var class_human_player =
[
    [ "get_input", "class_human_player.html#acfb5d97c40e498e4538158fd5f130cf0", null ],
    [ "get_ship_act", "class_human_player.html#a04cb3d46e6169d9e1d3970f8183dc570", null ],
    [ "get_ship_pos", "class_human_player.html#ac60e1aac17249cb2a4f52152402fae8a", null ]
];