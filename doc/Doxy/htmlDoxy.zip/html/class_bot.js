var class_bot =
[
    [ "Bot", "class_bot.html#a009d2f7f110658b81d9642ead285a638", null ],
    [ "gen_rand_coord", "class_bot.html#a02a9553a77ff1ce37bd6616bc437490f", null ],
    [ "gen_rand_ship_coord", "class_bot.html#a7d9db8be04fd63e4adae19cb819ed3fc", null ],
    [ "get_ship_act", "class_bot.html#a5c7b340226b4e95cc91cdd1fcd05afe1", null ],
    [ "get_ship_pos", "class_bot.html#ab283a837a3fab912b501b1b875362302", null ],
    [ "gh", "class_bot.html#a7d8634fa224558c61d379f584a286b58", null ]
];