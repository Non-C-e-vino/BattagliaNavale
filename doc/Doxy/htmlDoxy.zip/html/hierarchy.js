var hierarchy =
[
    [ "Admiral", "struct_admiral.html", null ],
    [ "GameHandler", "class_game_handler.html", null ],
    [ "Hull", "struct_hull.html", null ],
    [ "InLogger", "class_in_logger.html", null ],
    [ "OutLogger", "class_out_logger.html", null ],
    [ "Player", "class_player.html", [
      [ "GameHandler::Bot", "class_game_handler_1_1_bot.html", [
        [ "GameHandler::CleverBot", "class_game_handler_1_1_clever_bot.html", null ]
      ] ],
      [ "HumanPlayer", "class_human_player.html", null ]
    ] ],
    [ "Ship", "class_ship.html", [
      [ "Corazzata", "class_corazzata.html", null ],
      [ "NaveSupporto", "class_nave_supporto.html", null ],
      [ "Ricognitore", "class_ricognitore.html", null ]
    ] ],
    [ "XY", "struct_x_y.html", null ]
];