var class_game_handler_1_1_bot =
[
    [ "Bot", "class_game_handler_1_1_bot.html#ad917eb997dd7864d2386666080888a0a", null ],
    [ "gen_rand_coord", "class_game_handler_1_1_bot.html#a427d4347e3b16622ec2147855be09541", null ],
    [ "gen_rand_ship_coord", "class_game_handler_1_1_bot.html#a5109126dc77ed00d4753003c8cb74472", null ],
    [ "get_ship_act", "class_game_handler_1_1_bot.html#a621eb8f75f6fef41f07167d676a87b78", null ],
    [ "get_ship_pos", "class_game_handler_1_1_bot.html#a5a4fdf805e37ea6793f2df941c42ef0c", null ],
    [ "gh", "class_game_handler_1_1_bot.html#a896a39d0bf70259798b86b275419b2b4", null ]
];