var class_in_logger =
[
    [ "InLogger", "class_in_logger.html#ae057db5290317020c36cc55839d034ad", null ],
    [ "InLogger", "class_in_logger.html#a3c26346185eb1dee7e7037a4c00ad82e", null ],
    [ "~InLogger", "class_in_logger.html#a9870ec00199170c0cbbcd26b15ee2131", null ],
    [ "operator=", "class_in_logger.html#a1740135f5f5171ce599f02e7a0beb55a", null ],
    [ "read_coin_log", "class_in_logger.html#a91bd2ae739a69b1d448debca678115cd", null ],
    [ "read_log", "class_in_logger.html#a25358131977740e9521695a4268e4b1f", null ],
    [ "ifsptr", "class_in_logger.html#a50963facbcd50efba9d38ed911289ded", null ]
];