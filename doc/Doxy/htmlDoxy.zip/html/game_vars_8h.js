var game_vars_8h =
[
    [ "CORA", "game_vars_8h.html#af5cfd8b5d63d1ec674ae9c1f0be12c69", null ],
    [ "GRIDSIZE", "game_vars_8h.html#a1a475289e7875a7f4d60c1c61d1418af", null ],
    [ "LOGFILE", "game_vars_8h.html#a425b48cf5207db5947f5caf82ebecb5e", null ],
    [ "MAXTURNS", "game_vars_8h.html#a525abd38aba373c22604a72e9b9226ec", null ],
    [ "RICO", "game_vars_8h.html#afb9f06c4987595ed06da3d697a434f7a", null ],
    [ "SHIPS_TOT", "game_vars_8h.html#a8261485db1311b63dc265980656c71c8", null ],
    [ "SUPP", "game_vars_8h.html#a951f17e7027641c0ccae2fbe4c503888", null ]
];