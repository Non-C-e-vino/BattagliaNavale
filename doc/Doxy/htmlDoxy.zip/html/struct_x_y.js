var struct_x_y =
[
    [ "XY", "struct_x_y.html#adebaf8818ca064e7c6d14ef8a5e9774a", null ],
    [ "operator!=", "struct_x_y.html#a0fb389117f3c9956f4445af6be4c28e7", null ],
    [ "operator+=", "struct_x_y.html#ae0f6b98b6cd34679119bef63b105e966", null ],
    [ "operator<", "struct_x_y.html#ac97d465b3194950141137f4dbb7df45f", null ],
    [ "operator==", "struct_x_y.html#afbd34bd8e1726e4e0c6df3b196a9e72b", null ],
    [ "xy", "struct_x_y.html#a3c2187c9241b3934d0ddf1db161e1e89", null ]
];