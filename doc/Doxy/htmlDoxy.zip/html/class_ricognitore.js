var class_ricognitore =
[
    [ "Ricognitore", "class_ricognitore.html#adeaf8bb76f1b27b6f4b3b99c834d7b74", null ],
    [ "Ricognitore", "class_ricognitore.html#adb13a10562336705734a9bfd2c2f231a", null ],
    [ "full_heal", "class_ricognitore.html#a6fc0429172aa6ef665fee2e3f012b0de", null ],
    [ "get_action", "class_ricognitore.html#a053212963d8b54a82c625137ddc6cc99", null ],
    [ "get_hull", "class_ricognitore.html#a163d5986f0b49b019ed0ca0e5dfabe6c", null ],
    [ "get_size", "class_ricognitore.html#a398b83ac03b8c6de3ae9c8696ce0ae4b", null ],
    [ "heal", "class_ricognitore.html#a9beca3b3df65d6cd056bb449b6cf693f", null ],
    [ "is_core", "class_ricognitore.html#a06745a2040e18a45b435a981ae4e121b", null ],
    [ "operator=", "class_ricognitore.html#a17924b76565aa0c2c122109061be3395", null ],
    [ "hull", "class_ricognitore.html#a3e4858d72df47faa93b5f0a691e9122b", null ]
];