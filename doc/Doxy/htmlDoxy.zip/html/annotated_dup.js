var annotated_dup =
[
    [ "Admiral", "struct_admiral.html", "struct_admiral" ],
    [ "Corazzata", "class_corazzata.html", "class_corazzata" ],
    [ "GameHandler", "class_game_handler.html", "class_game_handler" ],
    [ "Hull", "struct_hull.html", "struct_hull" ],
    [ "HumanPlayer", "class_human_player.html", "class_human_player" ],
    [ "InLogger", "class_in_logger.html", "class_in_logger" ],
    [ "NaveSupporto", "class_nave_supporto.html", "class_nave_supporto" ],
    [ "OutLogger", "class_out_logger.html", "class_out_logger" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "Ricognitore", "class_ricognitore.html", "class_ricognitore" ],
    [ "Ship", "class_ship.html", "class_ship" ],
    [ "XY", "struct_x_y.html", "struct_x_y" ]
];