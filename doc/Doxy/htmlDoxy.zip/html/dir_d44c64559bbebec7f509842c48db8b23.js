var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "admiral.h", "admiral_8h.html", "admiral_8h" ],
    [ "coord.h", "coord_8h.html", "coord_8h" ],
    [ "corazzata.h", "corazzata_8h.html", "corazzata_8h" ],
    [ "gameHandler.h", "game_handler_8h.html", "game_handler_8h" ],
    [ "gameLoops.h", "game_loops_8h.html", "game_loops_8h" ],
    [ "gameVars.h", "game_vars_8h.html", "game_vars_8h" ],
    [ "humanPlayer.h", "human_player_8h.html", "human_player_8h" ],
    [ "logger.h", "logger_8h.html", "logger_8h" ],
    [ "naveSupporto.h", "nave_supporto_8h.html", "nave_supporto_8h" ],
    [ "player.h", "player_8h.html", "player_8h" ],
    [ "replayLoops.h", "replay_loops_8h.html", "replay_loops_8h" ],
    [ "ricognitore.h", "ricognitore_8h.html", "ricognitore_8h" ],
    [ "ship.h", "ship_8h.html", "ship_8h" ]
];