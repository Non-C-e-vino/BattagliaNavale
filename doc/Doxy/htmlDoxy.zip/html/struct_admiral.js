var struct_admiral =
[
    [ "Admiral", "struct_admiral.html#aaa0b85d6e9c8dd437faaaac6b87bbfbe", null ],
    [ "Admiral", "struct_admiral.html#a39133d0e007e70a80826094329be9496", null ],
    [ "~Admiral", "struct_admiral.html#a474b238f577da895fa744e8d0ac30b29", null ],
    [ "add_ship", "struct_admiral.html#a43eefae2732367f1c4a527146a9ee98a", null ],
    [ "delete_ship", "struct_admiral.html#a968accb001ddf591d83d2f6d8151b2e4", null ],
    [ "operator=", "struct_admiral.html#a4b194d7f8969614868aba7589df3ef10", null ],
    [ "attGrid", "struct_admiral.html#ae0f6202ce8371c0da892a3defb5ffcdd", null ],
    [ "defGrid", "struct_admiral.html#a7270c8d81b48b7dfa56d773b7ecd0df2", null ],
    [ "shipC", "struct_admiral.html#a3f5dd2fe9b5ad1e8c7931a549e258889", null ],
    [ "ships", "struct_admiral.html#a978caee73d4c73d8b1a1d3af30b859b5", null ]
];